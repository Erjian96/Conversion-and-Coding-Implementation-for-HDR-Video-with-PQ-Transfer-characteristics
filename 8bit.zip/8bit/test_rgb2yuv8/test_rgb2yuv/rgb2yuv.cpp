#include "stdlib.h"
#include "rgb2yuv.h"

//static float RGBYUV02990[256], RGBYUV05870[256], RGBYUV01140[256];
//static float RGBYUV01684[256], RGBYUV03316[256];
//static float RGBYUV04187[256], RGBYUV00813[256];

int RGB2YUV (int x_dim, int y_dim, void *bmp, void *y_out, void *u_out, void *v_out)
{
	//static int init_done = 0;
	long i, size;
	float *r, *g, *b;
	float *y, *u, *v;

	/*if (init_done == 0)
	{
		InitLookupTable();
		init_done = 1;
	}*/

	// check to see if x_dim and y_dim are divisible by 2
	if ((x_dim % 2) || (y_dim % 2)) return 1;
	size = x_dim * y_dim;

	// allocate memory
	y = (float *)y_out;
	u = (float *)u_out;
	v = (float *)v_out;
	b = (float *)bmp;
	// convert RGB to YUV
	
		for (i = 0; i < size; i++)
		{
			g = b + 1;
			r = b + 2;
			*y = (float)(  0.2627 * (*r) + 0.6780 * (*g) + 0.0593 * (*b));
			*u = (float)(- 0.139630063 * (*r) - 0.360369937 * (*g) + (*b)/2   );
			*v = (float)(  (*r)/2 - 0.459785705 * (*g) - 0.040214295 * (*b)   );
			b += 3;
			y ++;
			u ++;
			v ++;
		}
	return 0;
}


//void InitLookupTable()
//{
//	int i;
//
//	for (i = 0; i < 256; i++) RGBYUV02990[i] = (float)0.2990 * i;
//	for (i = 0; i < 256; i++) RGBYUV05870[i] = (float)0.5870 * i;
//	for (i = 0; i < 256; i++) RGBYUV01140[i] = (float)0.1140 * i;
//	for (i = 0; i < 256; i++) RGBYUV01684[i] = (float)0.1684 * i;
//	for (i = 0; i < 256; i++) RGBYUV03316[i] = (float)0.3316 * i;
//	for (i = 0; i < 256; i++) RGBYUV04187[i] = (float)0.4187 * i;
//	for (i = 0; i < 256; i++) RGBYUV00813[i] = (float)0.0813 * i;
//}


