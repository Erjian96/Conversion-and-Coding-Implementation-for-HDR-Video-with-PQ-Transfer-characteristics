#include "stdlib.h"
#include "rgb2yuv.h"

int SUBSAMPLE (int x_dim, int y_dim, void *u_out, void *v_out, void *subu, void *subv)
{
	long j, i, size;
	unsigned char *u, *v;
	unsigned char *pu1, *pu2, *pv1, *pv2, *psu, *psv;
	unsigned char *u_buffer, *v_buffer;
	unsigned char *sub_u_buf, *sub_v_buf;
	// check to see if x_dim and y_dim are divisible by 2
	if ((x_dim % 2) || (y_dim % 2)) return 1;
	size = x_dim * y_dim;

	// allocate memory
	u_buffer = (unsigned char *)u_out;
	v_buffer = (unsigned char *)v_out;
	sub_u_buf = (unsigned char *)subu;
	sub_v_buf = (unsigned char *)subv;
	
	if (!(u_buffer && v_buffer))
	{
		if (u_buffer) free(u_buffer);
		if (v_buffer) free(v_buffer);
		return 2;
	}
	u = u_buffer;
	v = v_buffer;
// subsample UV
	for (j = 0; j < y_dim/2; j ++)
	{
		psu = sub_u_buf + j * x_dim / 2;
		psv = sub_v_buf + j * x_dim / 2;
		pu1 = u_buffer + 2 * j * x_dim;
		pu2 = u_buffer + (2 * j + 1) * x_dim;
		pv1 = v_buffer + 2 * j * x_dim;
		pv2 = v_buffer + (2 * j + 1) * x_dim;
		for (i = 0; i < x_dim/2; i ++)
		{
			*psu = (*pu1 + *(pu1+1) + *pu2 + *(pu2+1)) / 4;
			*psv = (*pv1 + *(pv1+1) + *pv2 + *(pv2+1)) / 4;
			psu ++;
			psv ++;
			pu1 += 2;
			pu2 += 2;
			pv1 += 2;
			pv2 += 2;
		}
	}
	return 0;
}