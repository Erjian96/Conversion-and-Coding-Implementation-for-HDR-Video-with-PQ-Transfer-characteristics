#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include "yuv2rgb.h"

#define u_int8_t	unsigned __int8
#define u_int		unsigned __int32
#define u_int32_t	unsigned __int32


int main(int argc, char** argv)
{
	/* variables controlable from command line */
	u_int frameWidth = 1920;			
	u_int frameHeight = 1080;		

	/* internal variables */
	char* yuvFileName = NULL;
	char* rgbFileName = NULL;
	FILE* yuvFile = NULL;
	FILE* rgbFile = NULL;

	float* E_rgbBuf = NULL;
	float* O_rgbBuf = NULL;

	float* yBuf = NULL;
	float* uBuf = NULL;
	float* vBuf = NULL;

	unsigned char* y_10bit = NULL;
	unsigned char* u_10bit = NULL;
	unsigned char* v_10bit = NULL;

	unsigned char *sub_u_Buf, *sub_v_Buf;

	u_int32_t videoFramesWritten = 0;

	/* begin process command line */
	/* point to the specified file names */
	yuvFileName = argv[1];
	rgbFileName = argv[2];

	frameWidth = atoi(argv[3]);
	frameHeight = atoi(argv[4]);

	/* open the YUV file */
	yuvFile = fopen(yuvFileName, "rb");
	if (yuvFile == NULL)
	{
		printf("cannot find yuv file\n");
		exit(1);
	}
	else
	{
		printf("The input yuv file is %s\n", yuvFileName);
	}
	/* open the RAW file */
	rgbFile = fopen(rgbFileName, "wb");
	if (rgbFile == NULL)
	{
		printf("cannot find rgb file\n");
		exit(1);
	}
	else
	{
		printf("The output rgb file is %s\n", rgbFileName);
	}

	/* get the output buffers for a frame */
	E_rgbBuf = (float*)malloc(frameWidth * frameHeight * 3 * sizeof(float));
	O_rgbBuf = (float*)malloc(frameWidth * frameHeight * 3 * sizeof(float));

	/* get the input buffers for a frame */
	yBuf = (float*)malloc(frameWidth * frameHeight * sizeof(float));
	uBuf = (float*)malloc(frameWidth * frameHeight * sizeof(float));
	vBuf = (float*)malloc(frameWidth * frameHeight * sizeof(float));

	y_10bit = (u_int8_t*)malloc(frameWidth * frameHeight);
	u_10bit = (u_int8_t*)malloc(frameWidth * frameHeight);
	v_10bit = (u_int8_t*)malloc(frameWidth * frameHeight);

	sub_u_Buf = (u_int8_t*)malloc((frameWidth * frameHeight) / 4);
	sub_v_Buf = (u_int8_t*)malloc((frameWidth * frameHeight) / 4);

	if (E_rgbBuf == NULL || O_rgbBuf == NULL || yBuf == NULL || uBuf == NULL || vBuf == NULL || y_10bit == NULL || u_10bit == NULL || v_10bit == NULL || sub_u_Buf == NULL || sub_v_Buf == NULL)
	{
		printf("no enought memory\n");
		exit(1);
	}
	while (fread(y_10bit, 1, frameWidth * frameHeight, yuvFile) && fread(sub_u_Buf, 1, frameWidth * frameHeight /4, yuvFile)  
        && fread(sub_v_Buf, 1, frameWidth * frameHeight /4, yuvFile))  
    {  
		if(UPSAMPLE(frameWidth, frameHeight, sub_u_Buf, sub_v_Buf, u_10bit,  v_10bit))
		{
			printf("upsample error");
			return 0;
		}
		if(BIT2FLOAT (frameWidth, frameHeight, y_10bit, u_10bit, v_10bit, yBuf, uBuf, vBuf))
		{
			printf("10bit to float error");
			return 0;
		}
		if(YUV2RGB(frameWidth, frameHeight, yBuf, uBuf, vBuf, E_rgbBuf))
		{
			printf("yuv to rgb error");
			return 0;
		}
		if(EOTF (frameWidth, frameHeight, E_rgbBuf, O_rgbBuf))
		{
			printf("EOTF error");
			return 0;
		}
		//write rgbfile
		fwrite(O_rgbBuf, 1, frameWidth * frameHeight * 3 * sizeof(float), rgbFile);
		//rate of progress
		printf("\r...%d", ++videoFramesWritten);
	}
		printf("\n%u %ux%u video frames written\n", 
		videoFramesWritten, frameWidth, frameHeight);
	/* cleanup */
		
		free(E_rgbBuf);
		free(O_rgbBuf);
		free(yBuf);
		free(uBuf);
		free(vBuf);
		free(y_10bit);
		free(u_10bit);
		free(v_10bit);
		free(sub_u_Buf);
		free(sub_v_Buf);
		fclose(rgbFile);
		fclose(yuvFile);
	return(0);
}