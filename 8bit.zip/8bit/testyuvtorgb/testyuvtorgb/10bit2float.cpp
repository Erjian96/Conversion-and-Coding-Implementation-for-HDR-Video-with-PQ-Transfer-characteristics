#include <math.h>
#include "stdlib.h"
#include "yuv2rgb.h"
#define b 8

float Clip3 (float x, float y, float z)
{
	if(z < x)
	{
		return x;
	}
	else if (z > y)
	{
		return y;
	}
	else
	{
		return z;
	}
}


int BIT2FLOAT (int x_dim, int y_dim, void *y_10bit, void *u_10bit, void *v_10bit, void *y_float, void *u_float, void *v_float)
{
	long i, size;
	float *y, *u, *v;
	unsigned char *y_10b, *u_10b, *v_10b;

	y = (float *)y_float;
	u = (float *)u_float;
	v = (float *)v_float;
	y_10b = (unsigned char *)y_10bit;
	u_10b = (unsigned char *)u_10bit;
	v_10b = (unsigned char *)v_10bit;

	size = x_dim * y_dim;
	//y 10bit to float
	for(i = 0; i < size ; i ++)
	{
		*y = Clip3(0, 1.0, (float)((float)*y_10b - (float)(1 << (b - 4)))/ (float)(219 * (1 <<(b - 8))));
		y_10b ++;
		y ++;
	}
	//u 10bit to float
	for(i = 0; i < size ; i ++)
	{
		*u = Clip3(-0.5, 0.5, (float)((float)*u_10b - (float)(1 << (b - 1)))/ (float)(224 * (1 <<(b - 8))));
		u_10b ++;
		u ++;
	}
	//v 10bit to float
	for(i = 0; i < size ; i ++)
	{
		*v = Clip3(-0.5, 0.5, (float)((float)*v_10b - (float)(1 << (b - 1)))/ (float)(224 * (1 <<(b - 8))));
		v_10b ++;
		v ++;
	}
	
	return 0;
}