#include "stdlib.h"
#include "rgb2yuv.h"

int RGB2YUV (int x_dim, int y_dim, void *bmp, void *y_out, void *u_out, void *v_out)
{
	//static int init_done = 0;
	long i, size;
	float *r, *g, *b;
	float *y, *u, *v;

	// check to see if x_dim and y_dim are divisible by 2
	if ((x_dim % 2) || (y_dim % 2)) return 1;
	size = x_dim * y_dim;

	// allocate memory
	y = (float *)y_out;
	u = (float *)u_out;
	v = (float *)v_out;
	b = (float *)bmp;
	// convert RGB to YUV
	
		for (i = 0; i < size; i++)
		{
			g = b + 1;
			r = b + 2;
			*y = (float)(  0.2627 * (*r) + 0.6780 * (*g) + 0.0593 * (*b));
			*u = (float)(- 0.139630063 * (*r) - 0.360369937 * (*g) + (*b)/2   );
			*v = (float)(  (*r)/2 - 0.459785705 * (*g) - 0.040214295 * (*b)   );
			b += 3;
			y ++;
			u ++;
			v ++;
		}
	return 0;
}




