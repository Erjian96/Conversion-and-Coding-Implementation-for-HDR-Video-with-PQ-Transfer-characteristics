#include "stdlib.h"
#include "rgb2yuv.h"

int SUBSAMPLE (int x_dim, int y_dim, void *u_out, void *v_out, void *subu, void *subv)
{
	long j, i, size;
	unsigned char *psu, *psv;
	unsigned char *u_buffer, *v_buffer;
	unsigned char *sub_u_buf, *sub_v_buf;

	unsigned char * pu_low1,*pu_low2,*pu_low3,*pu_low4;
	unsigned char * pu_high1,*pu_high2,*pu_high3,*pu_high4;
	unsigned char * pv_low1,*pv_low2,*pv_low3,*pv_low4;
	unsigned char * pv_high1,*pv_high2,*pv_high3,*pv_high4;

	long int pu_1,pu_2,pu_3,pu_4,pv_1,pv_2,pv_3,pv_4;
	int u,v;
	long int puout_int,pvout_int;
	// check to see if x_dim and y_dim are divisible by 2
	if ((x_dim % 2) || (y_dim % 2)) return 1;
	size = x_dim * y_dim;

	// allocate memory
	u_buffer = (unsigned char *)u_out;
	v_buffer = (unsigned char *)v_out;
	sub_u_buf = (unsigned char *)subu;
	sub_v_buf = (unsigned char *)subv;
	
// subsample UV
	for (j = 0; j < y_dim/2; j ++)
	{
		psu = sub_u_buf + j * x_dim;
		psv = sub_v_buf + j * x_dim;

		pu_low1 =  u_buffer + 4 * j * x_dim;
		pu_high1 = u_buffer + 4 * j * x_dim + 1;
		pu_low2 =  u_buffer + 4 * j * x_dim + 2;
		pu_high2 = u_buffer + 4 * j * x_dim + 3;

		pu_low3 =  u_buffer + (2 * j + 1) * x_dim*2 ;
		pu_high3 = u_buffer + (2 * j + 1) * x_dim*2 + 1;
		pu_low4 =  u_buffer + (2 * j + 1) * x_dim*2 + 2;
		pu_high4 = u_buffer + (2 * j + 1) * x_dim*2 + 3;

		pv_low1 =  v_buffer + 4 * j * x_dim;
		pv_high1 = v_buffer + 4 * j * x_dim + 1;
		pv_low2 =  v_buffer + 4 * j * x_dim + 2;
		pv_high2 = v_buffer + 4 * j * x_dim + 3;

		pv_low3 =  v_buffer + (2 * j + 1) * x_dim*2;
		pv_high3 = v_buffer + (2 * j + 1) * x_dim*2 + 1;
		pv_low4 =  v_buffer + (2 * j + 1) * x_dim*2 + 2;
		pv_high4 = v_buffer + (2 * j + 1) * x_dim*2 + 3;

		for (i = 0; i < x_dim  / 2; i ++)
		{
			pu_1 = *pu_high1  * 256 + *pu_low1;
			pu_2 = *pu_high2  * 256 + *pu_low2;
			pu_3 = *pu_high3  * 256 + *pu_low3;
			pu_4 = *pu_high4  * 256 + *pu_low4;
			pv_1 = *pv_high1  * 256 + *pv_low1;
			pv_2 = *pv_high2  * 256 + *pv_low2;
			pv_3 = *pv_high3  * 256 + *pv_low3;
			pv_4 = *pv_high4  * 256 + *pv_low4;

			puout_int = (pu_1 + pu_2 + pu_3 + pu_4)/4;
			pvout_int = (pv_1 + pv_2 + pv_3 + pv_4)/4;

			*psu = (unsigned char)puout_int % 256;
			psu ++;
			u = puout_int / 256;
			*psu = (unsigned char)u;
			psu ++;

			*psv = (unsigned char)pvout_int % 256;
			psv ++;
			v = pvout_int / 256;
			*psv = (unsigned char)v;
			psv ++;

			pu_low1 += 4;
			pu_low2 += 4;
			pu_low3 += 4;
			pu_low4 += 4;
			pu_high1 += 4;
			pu_high2 += 4;
			pu_high3 += 4;
			pu_high4 += 4;
			pv_low1 += 4;
			pv_low2 += 4;
			pv_low3 += 4;
			pv_low4 += 4;
			pv_high1 += 4;
			pv_high2 += 4;
			pv_high3 += 4;
			pv_high4 += 4;
		}
	}
	return 0;
}