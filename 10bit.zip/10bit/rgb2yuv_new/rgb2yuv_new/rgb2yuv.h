int RGB2YUV (int x_dim, int y_dim, void *bmp, void *y_out, void *u_out, void *v_out);

int SUBSAMPLE (int x_dim, int y_dim, void *u_out, void *v_out, void *subu, void *subv);

int FLOAT210BIT(int x_dim, int y_dim, void *y_float, void *u_float, void *v_float, void *y_10bit,void *u_10bit, void *v_10bit);

int OETF(int x_dim, int y_dim, void *rgb, void *PQ_rgb);



int Clip3 (int x, int y, int z);
int Round (float x);
int Sign ( float x);

