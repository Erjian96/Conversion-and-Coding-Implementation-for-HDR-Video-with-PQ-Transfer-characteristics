#include <math.h>
#include "stdlib.h"
#include "rgb2yuv.h"
#define b 10

int Clip3 (int x, int y, int z)
{
	if(z < x)
	{
		return x;
	}
	else if (z > y)
	{
		return y;
	}
	else
	{
		return z;
	}
}

int Sign ( float x)
{
	if(x > 0)
	{
		return 1;
	}
	else if (x = 0 )
	{
		return 0;
	}
	else
	{
		return -1;
	}
}

int Round (float x)
{
	int y;
	y = Sign(x)*(int)(abs(x) + 0.5);
	return y;
}

int FLOAT210BIT (int x_dim, int y_dim, void *y_float, void *u_float, void *v_float, void *y_10bit,void *u_10bit, void *v_10bit)
{
	long i, size;
	float *y, *u, *v;
	unsigned char *y_10b, *u_10b, *v_10b;

	y = (float *)y_float;
	u = (float *)u_float;
	v = (float *)v_float;
	y_10b = (unsigned char *)y_10bit;
	u_10b = (unsigned char *)u_10bit;
	v_10b = (unsigned char *)v_10bit;
	long int y_int,u_int,v_int;
	int yy,uu,vv;
	int y1,u1,v1;
	size = x_dim * y_dim;
	//y float to 10bit
	for(i = 0; i < size ; i ++)
	{
		y_int = Clip3(0, (1 << b) - 1, Round((*y) * 219 * (1 << (b - 8)) + (1 << (b - 4))));
		y1 = y_int % 256;
		*y_10b = (unsigned char)y1;
		y_10b ++;

		yy = y_int / 256;
		*y_10b = (unsigned char)yy;
		y_10b ++;
		
		y ++;
	}
	//u float to 10bit
	for(i = 0; i < size ; i ++)
	{
		u_int = Clip3(0, (1 << b) - 1, Round((*u) * 224 * (1 << (b - 8)) + (1 << (b - 1))));
		u1 = u_int % 256;
		*u_10b = (unsigned char)u1;
		u_10b ++;

		uu = u_int / 256;
		*u_10b = (unsigned char)uu;
		u_10b ++;
		
		u ++;
	}
	//v float to 10bit
	for(i = 0; i < size ; i ++)
	{
		v_int = Clip3(0, (1 << b) - 1, Round((*v) * 224 * (1 << (b - 8)) + (1 << (b - 1))));
		v1 = v_int % 256;
		*v_10b = (unsigned char)v1;
		v_10b ++;

		vv = v_int / 256;
		*v_10b = (unsigned char)vv;
		v_10b ++;
		
		v ++;
	}

	return 0;
}