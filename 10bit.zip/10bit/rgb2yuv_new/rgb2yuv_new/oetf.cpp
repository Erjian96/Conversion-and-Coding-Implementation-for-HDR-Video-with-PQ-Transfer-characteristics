#include <math.h>
#include "stdlib.h"
#include "rgb2yuv.h"

static float M = 78.84375;
static float N = 0.1593017578125;
static float C1 = 0.8359375;
static float C2 = 18.8515625;
static float C3 = 18.6875;

int OETF(int x_dim, int y_dim, void *rgb, void *PQ_rgb)
{
	long i, j, size;
	float *o_rgb;
	float *e_rgb;
	float *E,*pE;/////��һ��

	size = x_dim * y_dim;

	o_rgb = (float *)rgb;
	e_rgb = (float *)PQ_rgb;
	E = (float *)malloc(size * 3 * sizeof(float));

	pE = E;

	for(i = 0; i < size * 3; i++)//��һ��
	{
		*pE = *o_rgb/10000;
		o_rgb ++;
		pE ++;
	}
	pE = E;
	for(j = 0; j < size * 3; j++)
	{
		*e_rgb = pow(((C1 + C2 * pow(*pE,N))/(1 + C3 * pow(*pE,N))),M);
		e_rgb ++;
		pE ++;
	}

	free(E);

	return 0;
}