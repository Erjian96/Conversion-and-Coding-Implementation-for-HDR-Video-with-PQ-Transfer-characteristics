#include <math.h>
#include "stdlib.h"
#include "yuv2rgb.h"
#define b 10

float Clip3 (float x, float y, float z)
{
	if(z < x)
	{
		return x;
	}
	else if (z > y)
	{
		return y;
	}
	else
	{
		return z;
	}
}


int BIT2FLOAT (int x_dim, int y_dim, void *y_10bit, void *u_10bit, void *v_10bit, void *y_float, void *u_float, void *v_float)
{
	long i, size;
	float *y, *u, *v;
	unsigned char *y_10b, *u_10b, *v_10b;
	long int y_int,u_int,v_int;

	y = (float *)y_float;
	u = (float *)u_float;
	v = (float *)v_float;
	y_10b = (unsigned char *)y_10bit;
	u_10b = (unsigned char *)u_10bit;
	v_10b = (unsigned char *)v_10bit;

	size = x_dim * y_dim;
	//y 10bit to float
	for(i = 0; i < size; i ++)
	{
		y_int = (int)(*(y_10b + 1) * 256 + *y_10b);
		*y = Clip3(0, 1.0, (float)((float)y_int - (float)(1 << (b - 4)))/ (219 * (1 <<(b - 8))));
		y_10b += 2; 
		y ++;
	}
	//u 10bit to float
	for(i = 0; i < size; i ++)
	{
		u_int = (int)(*(u_10b + 1) * 256 + *u_10b);
		*u = Clip3(-0.5, 0.5, (float)((float)u_int - (float)(1 << (b - 1)))/ (224 * (1 <<(b - 8))));
		u_10b += 2;
		u ++;
	}
	//v 10bit to float
	for(i = 0; i < size; i ++)
	{
		v_int = (int)(*(v_10b + 1) * 256 + *v_10b);
		*v = Clip3(-0.5, 0.5, (float)((float)v_int - (float)(1 << (b - 1)))/ (224 * (1 <<(b - 8))));
		v_10b += 2;
		v ++;
	}
	
	return 0;
}