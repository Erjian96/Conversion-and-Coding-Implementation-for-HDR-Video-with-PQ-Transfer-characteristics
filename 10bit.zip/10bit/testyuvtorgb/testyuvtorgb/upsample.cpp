#include "stdlib.h"
#include "yuv2rgb.h"

int UPSAMPLE (int x_dim,int y_dim,void *u_in,void *v_in,void *upu, void *upv)
{
	long i, j;
	unsigned char *add_u_buffer, *add_v_buffer;
	unsigned char *pu1, *pu2,*pu3, *pu4, *pv1, *pv2, *pv3, *pv4, *psu, *psv;
	unsigned char *u_buffer, *v_buffer;

	u_buffer = (unsigned char *)u_in;
	v_buffer = (unsigned char *)v_in;
	add_u_buffer = (unsigned char *)upu;
	add_v_buffer = (unsigned char *)upv;


	for (j = 0; j < y_dim/2; j ++)
	{
		psu = u_buffer + j * x_dim;
		psv = v_buffer + j * x_dim;

		pu1 = add_u_buffer + 4 * j * x_dim; 
		pu2 = add_u_buffer + 4 * j * x_dim + 2;
		pu3 = add_u_buffer + (2 * j + 1) * x_dim * 2;
		pu4 = add_u_buffer + (2 * j + 1) * x_dim * 2 + 2;

		pv1 = add_v_buffer + 4 * j * x_dim;
		pv2 = add_v_buffer + 4 * j * x_dim + 2;
		pv3 = add_v_buffer + (2 * j + 1) * x_dim * 2;
		pv4 = add_v_buffer + (2 * j + 1) * x_dim * 2 + 2;

		for (i = 0; i < x_dim/2; i ++)
		{
			*pu1 = *psu;
			*pu2 = *psu;
			*pu3 = *psu;
			*pu4 = *psu; 
			psu ++;
			pu1 ++;
			pu2 ++;
			pu3 ++;
			pu4 ++;

			*pu1 = *psu;
			*pu2 = *psu;
			*pu3 = *psu;
			*pu4 = *psu;
			psu ++;
			pu1 += 3;
			pu2 += 3;
			pu3 += 3;
			pu4 += 3;

			*pv1 = *psv;
			*pv2 = *psv;
			*pv3 = *psv;
			*pv4 = *psv; 
			psv ++;
			pv1 ++;
			pv2 ++;
			pv3 ++;
			pv4 ++;

			*pv1 = *psv;
			*pv2 = *psv;
			*pv3 = *psv;
			*pv4 = *psv;
			psv ++;
			pv1 += 3;
			pv2 += 3;
			pv3 += 3;
			pv4 += 3;
		}
	 }
	return 0;
}