#include <math.h>
#include "stdlib.h"
#include "yuv2rgb.h"

static float M = 78.84375;
static float N = 0.1593017578125;
static float C1 = 0.8359375;
static float C2 = 18.8515625;
static float C3 = 18.6875;

float MAX(float x, float y)
{
	if(x > y)
	{
		return x;
	}
	else
	{
		return y;
	}
}

int EOTF (int x_dim, int y_dim, void *Ergb, void *Orgb)
{
	long i, j, size;
	float *o_rgb;
	float *e_rgb;
	float *O,*pO;/////����һ��

	size = x_dim * y_dim;
	e_rgb = (float *)Ergb;
	o_rgb = (float *)Orgb;
	O = (float *)malloc(size * 3 * sizeof(float));
	pO = O;
	for(j = 0; j < size * 3; j++)
	{
		*pO = pow(MAX((pow(*e_rgb,1/M)) - C1,0.0)/(C2 - C3 * pow(*e_rgb,1/M)),1/N) * 10000;
		pO ++;
		e_rgb ++;
	}
	pO = O;
	for(i = 0; i < size * 3; i++)//����һ��
	{
		*o_rgb = (*pO);
		o_rgb ++;
		pO ++;
	}
	free(O);

	return 0;
}