int YUV2RGB (int x_dim,int y_dim,void *y_in,void *u_in,void *v_in,void *rgb_out);

int UPSAMPLE (int x_dim,int y_dim,void *u_in,void *v_in,void *upu, void *upv);

int BIT2FLOAT (int x_dim, int y_dim, void *y_10bit, void *u_10bit, void *v_10bit, void *y_float, void *u_float, void *v_float);

int EOTF (int x_dim, int y_dim, void *Ergb, void *Orgb);

float MAX(float x, float y);
float Clip3 (float x, float y, float z);
//void InitLookupTable();
